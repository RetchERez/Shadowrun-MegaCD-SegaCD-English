SHADOWRUN SEGA CD ENGLISH v1.0
By RetchERezzed

ABOUT THE TRANSLATION

Welcome to the English machine translation of Shadowrun for the Sega CD /
Mega-CD. This project makes the Japanese game's story, conversations, and
gameplay text accessible to English-speaking players.

This is a machine translation, with editing and playtesting to improve clarity,
dialogue layout, and progression. It is not an official localization or a
professional human translation. Some wording or nuances may still be imperfect.

This v1.0 release includes the latest dialogue-spacing improvements and script
corrections. Thank you for playing, and enjoy your time in the shadows!

INSTALLATION WITH FLIPS

You need your original Japanese game files, this release ZIP, and Flips
(Floating IPS). Keep backups of your game files and saves before starting.

1. Extract this release ZIP. The patch is:
   Shadowrun_SegaCD_English_v1.0.bps

2. Extract your original Japanese game archive too. The file to patch is:
   Shadowrun (Japan) (Track 1).bin
   Select the actual extracted BIN, not the game ZIP, CUE, Track 2, Track 3,
   or a previously English-patched Track 1. Renaming a different file will
   not make it compatible. This patch expects the original three-track dump.

3. Make a separate folder for your English copy. Copy the original CUE,
   Track 2, and Track 3 into that folder. Leave those files unchanged.

4. Open Flips and choose Apply Patch. Select the .bps file from this release.
   When Flips asks for the original file, select the clean Japanese Track 1
   from your extracted original game folder.

5. Save the patched output in your English-copy folder using the same name:
   Shadowrun (Japan) (Track 1).bin
   Do not save over your clean original. Keeping the original filename lets
   the copied CUE continue to point to the correct Track 1.

6. After Flips confirms success, open Shadowrun (Japan).cue from the English
   folder in your Sega CD emulator. Keep all three tracks together there.
   Configure your emulator with your own Japanese Sega CD BIOS as needed.

If your original files use different names, the FILE entries inside the CUE
must match the actual track filenames. Do not rename a BIN to .cue or .iso.

"THIS PATCH IS NOT INTENDED FOR THIS ROM"

This Flips message means the selected file does not match the original file
required by the patch. It is not an instruction to bypass the safety check.

Check that you selected the extracted Japanese Track 1, not an archive, CUE,
audio track, combined single-BIN disc, ISO, or a track with an older patch.
If updating from an older English release, start again from your clean original.

The required original Track 1 has:
Size: 218,696,016 bytes
CRC32: 04F1BC85
SHA256: 13A8A2C028FD7EF41EDDADE9A16848B03E7DCE2580E80A539AD349E7BC7E7E34

If your file does not match, stop and check which original dump you have.
Do not force the patch or turn off checksum validation. If it does match but
Flips still rejects it, check that you selected the BPS from this ZIP and
report the error, your Flips version, and the source file's fingerprint.

SAVE AND PLAY TIPS

Use the game's normal SAVE and LOAD options when changing patch versions.
An emulator savestate can keep old text in memory even after you change patches.

In town, saving is under ITEMS. If you see NO ITEMS, continue past that message
to reach SAVE. Saving is not available in every situation.

Before a difficult fight, check EQUIP as well as your inventory. Owning a weapon
does not necessarily mean your character has it equipped.

The walkthrough and dialogue script are separate documents, not part of this
patch ZIP. The walkthrough contains spoilers and marks unconfirmed guidance
with [NEEDS VERIFICATION].

KNOWN LIMITS AND FEEDBACK

The project has been tested and reviewed, but not every optional route or
possible outcome has been checked. A few optional Matrix text layouts remain
unchanged. This release should not be taken as a promise that no issues remain.

Found awkward wording, a display problem, or somewhere you cannot progress?
Please report the scenario, location, what you selected, and what happened.
A screenshot and your emulator name/version are especially helpful. Mention
that you are using this v1.0 FINAL package.

English Track 1 SHA256 after successful patching:
E6CC9B98AA7ECA6AFFE4242A24B3D2CEC41F474F25FC9A3BE1E06BBF38CEC091

Credits
Tester: Blamhammer
For thorough playtesting and valuable feedback that helped identify script
inconsistencies and progression issues, guiding dialogue corrections and
repairs to affected story paths.
