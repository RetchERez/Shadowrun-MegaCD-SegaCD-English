Shadowrun Sega CD English Translation
v1.1 Font Update
By RetchERezzed

ABOUT
An English machine translation of Shadowrun for the Sega CD, with corrections
informed by playtesting. This is an unofficial fan translation. Some wording
and capitalization may still be imperfect.

CHOOSE ONE PATCH
AllCaps: uppercase English dialogue with a heavier, clearer font, plus thicker
load/save lettering and matching numbers.
MixedCase: the same translation with sentence-aware dialogue and narration,
plus title-case commands, spells, equipment, Stats/Skills and shop labels.
Some original title artwork, legacy labels and battle-result captions remain
uppercase. Acronyms and weapon model codes retain their capitals.

Both editions build on v1.0 FINAL and include targeted dialogue/Matrix layout
cleanup, aligned letters and clearer Drain labels. MixedCase lowercase tails
fit the original shop fields. Spell values and mechanics are unchanged.
Choose the style you prefer; you do not need both patches to play.

INSTALLATION
You need your own clean Japanese disc image with separate BIN tracks and its
original CUE sheet, plus a BPS patcher such as Flips. No game files, BIOS,
emulator or patcher are included.

1. Extract this ZIP and back up your original disc files and saves.
2. In Flips, choose Apply Patch and select ONE of the included BPS files.
3. Select the clean Japanese Track 1 BIN as the original file. Do not select
   the CUE, another track, a ZIP, a CHD, an ISO or an already translated BIN.
4. Save the patched Track 1 under a new filename. Keep the original unchanged.
5. Place the patched BIN alongside your unchanged Track 2 and Track 3 files.
   Make a copy of your original CUE and open that copy in a text editor.
   Change only the quoted filename in its Track 1 FILE entry to match your
   patched BIN exactly. Leave all other entries and timing information alone.
6. Open the copied CUE in your Sega CD emulator. Start a new game or use the
   game's own LOAD option after a fresh boot.

Each patch is a complete English patch for clean Japanese Track 1. Do not
apply it over v1.0, combine the patches, or apply one after the other.

IF THE PATCHER SAYS "THIS PATCH IS NOT INTENDED FOR THIS ROM"
The selected file does not match the required original. Check that it is the
clean Japanese Track 1, not a translated file or a combined disc image.
The required file has these properties:
Size: 218696016 bytes
CRC32: 04F1BC85
SHA-256: 13a8a2c028fd7ef41eddade9a16848b03e7dce2580e80a539ad349e7bc7e7e34
A matching filename alone is not enough. Do not force the patch or disable
checksum checking. These patches do not support every disc-image layout.

IF OLD FONTS STILL APPEAR
Old emulator save states can retain old code and graphics. Close the emulator,
boot the newly patched CUE and load a normal in-game save instead. Keep your
original saves backed up; emulator save-state compatibility is not guaranteed.

SPELL STATISTICS
Drain is the strain a caster must resist after casting. F means the spell's
Force; F/2 means half that Force, followed by its modifier. The separate
L, M, S or D letter is the severity rating, from lowest to highest. Damage and
Drain are different fields. This notation is intentional, not broken text.

TESTING AND LIMITS
Both patches were successfully reapplied to the required original and checked
for exact results. 112 automated tests passed. Fresh screenshots cover selected
dialogue, menus, save/load, equipment, shops and Matrix scenes in both editions.
This update has not had another complete beginning-to-ending playthrough.
Every branch, transaction and screen, and real hardware, have not been tested.
MixedCase conversion is automated with project-specific name corrections,
not a new human-edited translation. Screenshots, walkthrough and dialogue
script are separate from this patch package.

CREDITS
Translation project: RetchERezzed
Tester: Blamhammer
Special thanks to Blamhammer for finding script inconsistencies and progression
issues, and helping improve the adventure's clarity and reliability.

Shadowrun and the original game belong to their respective rights holders.
