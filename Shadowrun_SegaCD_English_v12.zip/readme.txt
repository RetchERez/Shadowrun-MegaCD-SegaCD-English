Shadowrun Sega CD English Translation
v1.2
By RetchERezzed

ABOUT
An unofficial English machine translation of Shadowrun for Sega CD / Mega-CD,
with editing and playtesting. This is not a professional human translation;
some wording or nuances may still be imperfect.

CHOOSE ONE PATCH
AllCaps: uppercase dialogue with the heavier font introduced in v1.1.
MixedCase: sentence-case dialogue and mixed-case menus, spells and equipment.
Some artwork, abbreviations and battle labels remain uppercase.
Both include the full translation. Choose whichever style you prefer.

WHAT'S NEW IN v1.2
- Corrected Blackbird's scrambled name in battle, including the target panel
  and attack message. The correction is included in both editions.
- Retained the v1.1 fonts, dialogue layout, interface updates and prior fixes.
- Added the Ares display tip below. No Ares-specific game change was made.

INSTALLATION
Use your own clean Japanese three-track BIN/CUE dump and a BPS patcher such
as Flips. Back up your original files and saves first.

1. Extract this ZIP. In Flips, choose Apply Patch and select ONE file:
   Shadowrun_SegaCD_English_v1.2_AllCaps.bps
   Shadowrun_SegaCD_English_v1.2_MixedCase.bps
2. For the original file, select Shadowrun (Japan) (Track 1).bin from your
   clean Japanese dump. Do not select the ZIP, CUE, audio tracks, ISO, CHD,
   combined single-BIN image, or a previously translated Track 1.
3. Save the patched output in a separate folder using the original Track 1
   filename. Copy your original CUE, Track 2 and Track 3 into that folder.
4. Open the copied CUE in your Sega CD emulator, with your own required BIOS.
   If you renamed a track, its filename must match its FILE entry in the CUE.
   Leave all track timing information unchanged.

Apply only one patch, directly to clean Japanese Track 1. Do not apply over
v1.0 or v1.1, and do not stack the AllCaps and MixedCase patches.

PATCHER ERROR: "THIS PATCH IS NOT INTENDED FOR THIS ROM"
Check the source file, not just its name. The required Track 1 is:
Size: 218696016 bytes
CRC32: 04F1BC85
SHA-256:
13a8a2c028fd7ef41eddade9a16848b03e7dce2580e80a539ad349e7bc7e7e34
Do not force the patch or disable checksum checking.

UPDATING AND PLAYING
Restart the emulator and use the game's normal LOAD option. Old emulator
savestates can retain outdated code and graphics; keep your saves backed up.
In town, SAVE is under ITEMS; continue past NO ITEMS if it appears.
Check EQUIP before difficult fights: owning a weapon does not equip it.

ARES DISPLAY TIP
If you see colored speckles along the bottom border, try turning overscan
off. This removed the border pixels in tested Ares v148 intro scenes without
changing the game picture. They also appeared in v1.0 in those tests.
This is a display-setting workaround, not a confirmed fix for every Ares
report. CHD and the reporter's unknown Ares version were not tested.

TESTING AND FEEDBACK
Both patches were reapplied to clean Track 1 and checked for exact results.
Blackbird's correction was verified in matching Scenario 7 battle replays
in both editions. The equivalent changes in two other encounters received
code checks, not new gameplay replays. This update has not had another full
playthrough or hardware test. Please report issues with your edition,
scenario, location, emulator version and a screenshot when possible.

PATCHED TRACK 1 SHA-256
AllCaps:
b792c88b8356fbfe3731dedfafbe4903339562c8f78a0a5696ee3ebf21abec95
MixedCase:
ac5fef469a8fd13cec8b3e0f568a87c5384348ead9f80e98147fc26bf5f70ae2

CREDITS
Translation project: RetchERezzed
Tester: Blamhammer
Special thanks to Blamhammer for thorough playtesting and feedback that
helped uncover script inconsistencies and repair progression problems.
Thanks to RetroGameTalk and its community for their support!

Shadowrun and the original game belong to their respective rights holders.
No game files, BIOS, emulator, saves or savestates are included.
